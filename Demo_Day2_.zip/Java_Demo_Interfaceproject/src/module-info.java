/**
 * 
 */
/**
 * 
 */
module Java_Demo_Interfaceproject {
}