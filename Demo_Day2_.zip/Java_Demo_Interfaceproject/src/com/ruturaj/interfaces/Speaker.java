package com.ruturaj.interfaces;

public interface Speaker {
	 int DURATION = 45;

	    // Abstract methods
	    void speak(); // Method to speak
	    void topic(); // Method to define the topic

	    /*
	     Before Java 8, interfaces could only have abstract methods.
	     To add a new method, all implementing classes had to override it,
	     which could lead to issues in backward compatibility.

	     Java 8 introduced default methods, allowing interfaces to provide
	     method implementations without forcing the implementing classes to override them.
	    */

	    // Default method with implementation
	    default void show() {
	        System.out.println("++++ DEFAULT IMPLEMENTATION ++++");
	    }
}
