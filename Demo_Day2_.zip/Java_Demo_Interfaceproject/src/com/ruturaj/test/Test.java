package com.ruturaj.test;

import com.ruturaj.interfaces.Speaker;
import com.ruturaj.model.Politician;
import com.ruturaj.model.Preacher;
import com.ruturaj.model.Trainer;

public class Test {
	public static void main(String[] args) {
        
        Speaker s1 = new Politician();
        Speaker s2 = new Preacher();
        Speaker s3 = new Trainer();

        
        display(s1);
        display(s2);
        display(s3);
    }

    private static void display(Speaker speaker) {
        speaker.speak();
        speaker.topic();
        speaker.show();
        System.out.println();
    }
}

/*OUTPUT ----->
 *  Politician speaks on Political Pros/Cons...
Duration:: 55 mins.
India's IT Sector Contribution During the Covid Pandemic
++++ DEFAULT IMPLEMENTATION ++++

Preacher speaks about spiritual guidance...
Duration:: 50 mins.
Importance Of Prayers For A Peaceful Mind
++++ DEFAULT IMPLEMENTATION ++++

I am YURI, the Trainer, who trains...
Duration:: 70 mins.
How to execute a proper football spot kick
Showing and demonstrating the Panenka kick


 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
