package com.ruturaj.model;

import com.ruturaj.interfaces.Speaker;

public class Politician implements Speaker {

    @Override
    public void speak() {
        System.out.println("Politician speaks on Political Pros/Cons...");
        System.out.println("Duration:: " + (Speaker.DURATION + 10) + " mins.");
    }

    @Override
    public void topic() {
        System.out.println("India's IT Sector Contribution During the Covid Pandemic");
    }
}