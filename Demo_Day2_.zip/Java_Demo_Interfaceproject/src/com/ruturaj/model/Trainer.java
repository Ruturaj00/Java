package com.ruturaj.model;

import com.ruturaj.interfaces.Speaker;

public class Trainer implements Speaker {

    @Override
    public void speak() {
        System.out.println("I am YURI, the Trainer, who trains...");
        System.out.println("Duration:: " + (Speaker.DURATION + 25) + " mins.");
    }

    @Override
    public void topic() {
        System.out.println("How to execute a proper football spot kick");
    }

    @Override
    public void show() {
        System.out.println("Showing and demonstrating the Panenka kick");
    }
}