package com.ruturaj.model;

import com.ruturaj.interfaces.Speaker;

public class Preacher implements Speaker {

    @Override
    public void speak() {
        System.out.println("Preacher speaks about spiritual guidance...");
        System.out.println("Duration:: " + (Speaker.DURATION + 5) + " mins.");
    }

    @Override
    public void topic() {
        System.out.println("Importance Of Prayers For A Peaceful Mind");
    }
}