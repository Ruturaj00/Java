package com.ruturaj.test;

import com.ruturaj.model.OverloadedMethods;

public class TestMethodOverloading {
	public static void main(String[] args) {
        OverloadedMethods obj = new OverloadedMethods();

        obj.sum(3, 4);
        obj.sum(3, 4.5);
        obj.sum(3.2, 4.3);
        obj.sum(4.2, 3);
        obj.sum(2, 3, 4);
    }
}
/* OUTPUT ----->
SUM Of 3, 4 is 7
SUM Of 3, 4.5 is 7.5
SUM Of 3.2, 4.3 is 7.5
SUM Of 4.2, 3 is 7.2
SUM Of 2, 3, 4 is 9
*/