package com.ruturaj.model;

public class OverloadedMethods {

    public void sum(int n1, int n2) {
        System.out.println("SUM Of " + n1 + ", " + n2 + " is " + (n1 + n2));
    }

    public void sum(int n1, int n2, int n3) {
        System.out.println("SUM Of " + n1 + ", " + n2 + ", " + n3 + " is " + (n1 + n2 + n3));
    }

    public void sum(double n1, double n2) {
        System.out.println("SUM Of " + n1 + ", " + n2 + " is " + (n1 + n2));
    }

    public void sum(int n1, double n2) {
        System.out.println("SUM Of " + n1 + ", " + n2 + " is " + (n1 + n2));
    }

    public void sum(double n1, int n2) {
        System.out.println("SUM Of " + n1 + ", " + n2 + " is " + (n1 + n2));
    }
}
