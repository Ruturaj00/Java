package com.ruturaj.test;

import com.ruturaj.model.Person;
import com.ruturaj.model.Student;

public class TestInheritance {
	public static void main(String[] args) {

        Person person = new Person();
        System.out.println("==================");

        Student student1 = new Student();
        System.out.println("==================");

        System.out.println(student1);

        Person student2 = new Student(101, "Ruturaj", "Savakare", 2024, "BE", 77);
        System.out.println("==================");

        System.out.println(student2);
        student2.printInfo();
    }
}
/*OUTPUT --->
 * 
 * ++++ Default Constructor SuperClass ++++
==================
++++ Default Constructor SuperClass ++++
++++ Default Constructor SubClass ++++
==================
Student [courseName=null, percent=0.0, yearOfPassing=0, uId=0, firstName=null, lastName=null]
++++ Parameterized Constructor SuperClass ++++
==================
Student [courseName=BE, percent=77.0, yearOfPassing=2024, uId=101, firstName=Ruturaj, lastName=Savakare]
UID : 101
FIRSTNAME : Ruturaj
LASTNAME : Savakare
PASSING YEAR: 2024
COURSE : BE
PERCENT : 77.0

 * 
 * 
 * 
 * 
 */
