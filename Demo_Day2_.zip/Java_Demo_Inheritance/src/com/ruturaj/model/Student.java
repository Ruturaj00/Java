package com.ruturaj.model;

public class Student extends Person {
	 private int yearOfPassing;
	    private String courseName;
	    private double percent;

	    public Student() {
	        super();
	        System.out.println("++++ Default Constructor SubClass ++++");
	    }

	    public Student(int uId, String firstName, String lastName, int yearOfPassing, String courseName, double percent) {
	        super(uId, firstName, lastName);
	        this.yearOfPassing = yearOfPassing;
	        this.courseName = courseName;
	        this.percent = percent;
	    }

	    public Student(int uId, String firstName, String lastName) {
	        super(uId, firstName, lastName);
	    }

	    public int getYearOfPassing() {
	        return yearOfPassing;
	    }

	    public void setYearOfPassing(int yearOfPassing) {
	        this.yearOfPassing = yearOfPassing;
	    }

	    public String getCourseName() {
	        return courseName;
	    }

	    public void setCourseName(String courseName) {
	        this.courseName = courseName;
	    }

	    public double getPercent() {
	        return percent;
	    }

	    public void setPercent(double percent) {
	        this.percent = percent;
	    }

	    @Override
	    public void printInfo() {
	        System.out.println("UID : " + uId);
	        System.out.println("FIRSTNAME : " + firstName);
	        System.out.println("LASTNAME : " + lastName);
	        System.out.println("PASSING YEAR: " + yearOfPassing);
	        System.out.println("COURSE : " + courseName);
	        System.out.println("PERCENT : " + percent);
	    }

	    @Override
	    public String toString() {
	        return "Student [courseName=" + courseName + ", percent=" + percent + ", yearOfPassing=" + yearOfPassing
	                + ", uId=" + uId + ", firstName=" + firstName + ", lastName=" + lastName + "]";
	    }
}
