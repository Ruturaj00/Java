package com.ruturaj.model;

public class Person {
	protected int uId;
    protected String firstName;
    protected String lastName;

    public Person() {
        super();
        System.out.println("++++ Default Constructor SuperClass ++++");
    }

    public Person(int uId, String firstName, String lastName) {
        super();
        this.uId = uId;
        this.firstName = firstName;
        this.lastName = lastName;
        System.out.println("++++ Parameterized Constructor SuperClass ++++");
    }

    public int getUId() {
        return uId;
    }

    public void setUId(int uId) {
        this.uId = uId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "Person [uId=" + uId + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }

    public void printInfo() {
        System.out.println("Print Info Of Person");
    }
}
