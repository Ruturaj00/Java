/**
 * 
 */
/**
 * 
 */
module Java_Demo_Inheritance {
}