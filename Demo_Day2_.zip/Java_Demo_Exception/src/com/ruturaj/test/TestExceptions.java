package com.ruturaj.test;

import java.util.Scanner;

import com.ruturaj.exception.MaxRangeExceededException;
import com.ruturaj.exception.MinRangeExceededException;

public class TestExceptions {
		private static void calculateFactorial(int num) throws MinRangeExceededException, MaxRangeExceededException {
        int fact = 1;

        if (num < 1) {
            throw new MinRangeExceededException(num);
        } else if (num > 6) {
            throw new MaxRangeExceededException(num);
        }

        for (int i = 1; i <= num; i++) {
            fact *= i;
        }

        System.out.println("Factorial: " + fact);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("Enter a number: ");
            int num = Integer.parseInt(sc.nextLine());

            calculateFactorial(num);
        } catch (MaxRangeExceededException e) {
            System.out.println(e);
            e.printStackTrace();
        } catch (MinRangeExceededException e) {
            System.out.println(e);
            e.printStackTrace();
        } finally {
            sc.close();
        }
    }
}

/*   OUTPUT --->
	 *  Enter a number: 
	-1
	Min Range Exceeded: [-1]
	Min Range Exceeded: [-1]
 * 
 * 
 * 
 * 
 * 
 * 
 */
