package com.ruturaj.exception;

public class MaxRangeExceededException extends Exception {
	    private int details;

	    public MaxRangeExceededException(int details) {
	        this.details = details;
	    }

	    @Override
	    public String toString() {
	        return "Exceeded Max Range: [" + details + "]";
	    }
}
