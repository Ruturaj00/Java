package com.ruturaj.exception;

public class MinRangeExceededException extends Exception {

    private int details;

    public MinRangeExceededException(int details) {
        this.details = details;
    }

    @Override
    public String toString() {
        return "Min Range Exceeded: [" + details + "]";
    }
}
