package com.ruturaj.model;

abstract public class Shape2D {
    protected double dim1;
    protected double dim2;
    protected String color;

    
    public Shape2D(double dim1, double dim2) {
        this.dim1 = dim1;
        this.dim2 = dim2;
    }

    
    public Shape2D() {}

  
    public void setColor(String color) {
        this.color = color;
    }

   
    public String getColor() {
        return color;
    }

    abstract public void draw();
    abstract public void area();
}

