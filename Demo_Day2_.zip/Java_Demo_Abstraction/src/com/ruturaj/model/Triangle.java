package com.ruturaj.model;

public class Triangle extends Shape2D {

    public Triangle(double dim1, double dim2) {
        super(dim1, dim2);
    }

    @Override
    public void draw() {
        System.out.println("++++ Drawing TRIANGLE ++++");
    }

   
    @Override
    public void area() {
        System.out.println("++++ AREA :: " + (dim1 * dim2 * 0.5) + " ++++");
    }
}