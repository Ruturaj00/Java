package com.ruturaj.model;

public class Rectangle extends Shape2D {

    public Rectangle(double dim1, double dim2) {
        super(dim1, dim2);
    }

    
    @Override
    public void draw() {
        System.out.println("++++ Drawing RECTANGLE ++++");
    }

    @Override
    public void area() {
        System.out.println("++++ AREA :: " + (dim1 * dim2) + " ++++");
    }
}