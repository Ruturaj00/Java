package com.ruturaj.test;

import com.ruturaj.model.Rectangle;
import com.ruturaj.model.Shape2D;
import com.ruturaj.model.Triangle;

public class TestAbstract {
    public static void main(String[] args) {
        
        Rectangle r = new Rectangle(2.4, 3.2);
        Triangle t = new Triangle(4.2, 5.3);

        
        r.setColor("BLUE");
        t.setColor("GREEN");

       
        processShapes(r);
        processShapes(t);
    }

    private static void processShapes(Shape2D shape) {
       
        if (shape instanceof Rectangle) {
            System.out.println("Shape refers to Rectangle");
        } else if (shape instanceof Triangle) {
            System.out.println("Shape refers to Triangle");
        }

        shape.draw();
        shape.area();
        System.out.println("COLOR:: " + shape.getColor());
    }
}	

/*
	Shape refers to Rectangle
++++ Drawing RECTANGLE ++++
++++ AREA :: 7.68 ++++
COLOR:: BLUE
Shape refers to Triangle
++++ Drawing TRIANGLE ++++
++++ AREA :: 11.13 ++++
COLOR:: GREEN






*/