package com.ruturaj.model;

public class Address {

    private String addrLine;
    private String city;
    private String country;

    public Address() {
        super();
    }

    public Address(String addrLine, String city, String country) {
        super();
        this.addrLine = addrLine;
        this.city = city;
        this.country = country;
    }

    public String getAddrLine() {
        return addrLine;
    }

    public void setAddrLine(String addrLine) {
        this.addrLine = addrLine;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void printAddressInfo() {
        System.out.println("Address Line: " + addrLine);
        System.out.println("City of residence: " + city);
        System.out.println("Country: " + country);
    }
}
