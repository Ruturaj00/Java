package com.ruturaj.model;

public class College {
	 private String collegeName;
	    private String collegeCity;
	    private String university;

	    public College() {
	        super();
	    }

	    public College(String collegeName, String collegeCity, String university) {
	        super();
	        this.collegeName = collegeName;
	        this.collegeCity = collegeCity;
	        this.university = university;
	    }

	    public String getCollegeName() {
	        return collegeName;
	    }

	    public void setCollegeName(String collegeName) {
	        this.collegeName = collegeName;
	    }

	    public String getCollegeCity() {
	        return collegeCity;
	    }

	    public void setCollegeCity(String collegeCity) {
	        this.collegeCity = collegeCity;
	    }

	    public String getUniversity() {
	        return university;
	    }

	    public void setUniversity(String university) {
	        this.university = university;
	    }

	    public void printCollegeInfo() {
	        System.out.println("College Name: " + collegeName);
	        System.out.println("College City: " + collegeCity);
	        System.out.println("Affiliated To University: " + university);
	    }
}
