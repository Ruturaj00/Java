package com.ruturaj.model;

public class Student {
	private int rollNo;
    private String firstName;
    private String lastName;
    private Address address;
    private College college;

    public Student() {
        super();
    }

    public Student(int rollNo, String firstName, String lastName, Address address, College college) {
        super();
        this.rollNo = rollNo;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.college = college;
    }

    public int getRollNo() {
        return rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public College getCollege() {
        return college;
    }

    public void setCollege(College college) {
        this.college = college;
    }

    public void printStudentInfo() {
        System.out.println("Student Info:");
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Address:");
        address.printAddressInfo();
        System.out.println("College:");
        college.printCollegeInfo();
    }
}
