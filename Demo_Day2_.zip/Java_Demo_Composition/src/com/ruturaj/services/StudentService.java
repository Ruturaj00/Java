package com.ruturaj.services;

import com.ruturaj.model.Address;
import com.ruturaj.model.College;
import com.ruturaj.model.Student;

public class StudentService {
	private Student student;

    
    public void createStudent(int rollNo, String firstName, String lastName,
                              String addrLine, String city, String country,
                              String collegeName, String collegeCity, String university) {

        Address address = new Address();
        address.setAddrLine(addrLine);
        address.setCity(city);
        address.setCountry(country);

        
        College college = new College();
        college.setCollegeCity(collegeCity);
        college.setCollegeName(collegeName);
        college.setUniversity(university);

      
        student = new Student();
        student.setRollNo(rollNo);
        student.setFirstName(firstName);
        student.setLastName(lastName);
        student.setAddress(address); 
        student.setCollege(college); 
    }

    public void printStudent() {
        student.printStudentInfo();
    }
}
 