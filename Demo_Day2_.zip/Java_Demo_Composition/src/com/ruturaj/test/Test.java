package com.ruturaj.test;

import com.ruturaj.services.StudentService;

public class Test {
	public static void main(String[] args) {
        StudentService studentService = new StudentService();
        studentService.createStudent(10, "Ameya", "Joshi", "Dhayari Sg Rd", "Pune", "India", "IMCS", "PUNE", "PUNE");
        studentService.printStudent();
    }
}
